<?php require_once 'views/template/header.php'; ?>

<h2 class="text-xl mb-4"><?php echo isset($panen) ? 'Edit Panen' : 'Add Panen'; ?></h2>
<form action="index.php?entity=panen&action=<?php echo isset($panen) ? 'update&id=' . $panen['id_panen'] : 'save'; ?>" method="POST" class="space-y-4">
    <div>
        <label class="block">Tanggal Panen:</label>
        <input type="date" name="tanggal" value="<?php echo isset($panen) ? $panen['tanggal_panen'] : ''; ?>" class="border p-2 w-full" required>
    </div>
    <div>
        <label class="block">Jumlah (kg):</label>
        <input type="number" step="0.01" name="jumlah" value="<?php echo isset($panen) ? $panen['jumlah_kg'] : ''; ?>" class="border p-2 w-full" required>
    </div>
    <div>
        <label class="block">Kualitas:</label>
        <input type="text" name="kualitas" value="<?php echo isset($panen) ? $panen['kualitas'] : ''; ?>" class="border p-2 w-full">
    </div>
    <div>
        <label class="block">Tanaman:</label>
        <select name="id_tanaman" class="border p-2 w-full" required>
            <?php foreach ($tanamans as $t): ?>
                <option value="<?php echo $t['id_tanaman']; ?>" <?php echo isset($panen) && $panen['id_tanaman'] == $t['id_tanaman'] ? 'selected' : ''; ?>>
                    <?php echo $t['nama_tanaman']; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Save</button>
</form>


<?php require_once 'views/template/footer.php'; ?>
