<?php require_once 'views/template/header.php'; ?>

<h2 class="text-xl mb-4">Daftar Tanaman</h2>
<a href="index.php?entity=tanaman&action=add" class="bg-blue-500 text-white px-4 py-2 rounded mb-4 inline-block">Tambah Tanaman</a>
<table class="w-full border">
    <tr class="bg-gray-200">
        <th class="border p-2">Nama</th>
        <th class="border p-2">Jenis</th>
        <th class="border p-2">Kebun</th>
        <th class="border p-2">Actions</th>
    </tr>
    <?php foreach ($tanamanList as $t): ?>
    <tr>
        <td class="border p-2"><?php echo $t['nama_tanaman']; ?></td>
        <td class="border p-2"><?php echo $t['jenis']; ?></td>
        <td class="border p-2"><?php echo $t['nama_kebun']; ?></td>
        <td class="border p-2">
            <a href="index.php?entity=tanaman&action=edit&id=<?php echo $t['id_tanaman']; ?>" class="text-blue-500">Edit</a>
            <a href="index.php?entity=tanaman&action=delete&id=<?php echo $t['id_tanaman']; ?>" class="text-red-500 ml-2" onclick="return confirm('Yakin ingin menghapus?');">Delete</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php require_once 'views/template/footer.php'; ?>
