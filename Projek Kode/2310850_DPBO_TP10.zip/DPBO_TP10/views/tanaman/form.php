<?php require_once 'views/template/header.php'; ?>

<h2 class="text-xl mb-4"><?php echo isset($tanaman) ? 'Edit Tanaman' : 'Add Tanaman'; ?></h2>
<form action="index.php?entity=tanaman&action=<?php echo isset($tanaman) ? 'update&id=' . $tanaman['id_tanaman'] : 'save'; ?>" method="POST" class="space-y-4">
    <div>
        <label class="block">Nama Tanaman:</label>
        <input type="text" name="nama" value="<?php echo isset($tanaman) ? $tanaman['nama_tanaman'] : ''; ?>" class="border p-2 w-full" required>
    </div>
    <div>
        <label class="block">Jenis:</label>
        <input type="text" name="jenis" value="<?php echo isset($tanaman) ? $tanaman['jenis'] : ''; ?>" class="border p-2 w-full">
    </div>
    <div>
        <label class="block">Kebun:</label>
        <select name="id_kebun" class="border p-2 w-full" required>
            <?php foreach ($kebuns as $k): ?>
                <option value="<?php echo $k['id_kebun']; ?>" <?php echo isset($tanaman) && $tanaman['id_kebun'] == $k['id_kebun'] ? 'selected' : ''; ?>>
                    <?php echo $k['nama_kebun']; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Save</button>
</form>

<?php require_once 'views/template/footer.php'; ?>
