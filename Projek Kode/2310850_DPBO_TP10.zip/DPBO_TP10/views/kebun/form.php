<?php require_once 'views/template/header.php'; ?>

<h2 class="text-xl mb-4"><?php echo isset($kebun) ? 'Edit Kebun' : 'Add Kebun'; ?></h2>
<form action="index.php?entity=kebun&action=<?php echo isset($kebun) ? 'update&id=' . $kebun['id_kebun'] : 'save'; ?>" method="POST" class="space-y-4">

    <div>
        <label class="block">Nama Kebun:</label>
        <input type="text" name="nama" value="<?php echo isset($kebun) ? $kebun['nama_kebun'] : ''; ?>" class="border p-2 w-full" required>
    </div>
    <div>
        <label class="block">Lokasi:</label>
        <input type="text" name="lokasi" value="<?php echo isset($kebun) ? $kebun['lokasi'] : ''; ?>" class="border p-2 w-full" required>
    </div>
    <div>
        <label class="block">Luas (ha):</label>
        <input type="number" step="0.01" name="luas" value="<?php echo isset($kebun) ? $kebun['luas_ha'] : ''; ?>" class="border p-2 w-full" required>
    </div>
    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Save</button>
</form>

<?php require_once 'views/template/footer.php'; ?>
