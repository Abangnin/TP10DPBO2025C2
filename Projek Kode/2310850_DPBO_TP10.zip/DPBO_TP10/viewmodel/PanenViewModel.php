<?php
require_once 'model/Panen.php';
require_once 'model/Tanaman.php';

class PanenViewModel {
    private $panen;
    private $tanaman;
    private $kebun;

    public function __construct() {
        $this->panen = new Panen();
        $this->tanaman = new Tanaman();
        $this->kebun = new Kebun();
    }

    public function getPanenList() {
        return $this->panen->getAll();
    }

    public function getPanenById($id) {
        return $this->panen->getById($id);
    }

    public function getKebuns() {
    return $this->kebun->getAll();
    }

    public function getTanamans() {
        return $this->tanaman->getAll();
    }

    public function getTanamanList() {
        return $this->tanaman->getAll();
    }

    public function addPanen($id_tanaman, $tanggal, $jumlah, $kualitas) {
        return $this->panen->create($id_tanaman, $tanggal, $jumlah, $kualitas);
    }

    public function updatePanen($id, $id_tanaman, $tanggal, $jumlah, $kualitas) {
        return $this->panen->update($id, $id_tanaman, $tanggal, $jumlah, $kualitas);
    }

    public function deletePanen($id) {
        return $this->panen->delete($id);
    }
}
?>
