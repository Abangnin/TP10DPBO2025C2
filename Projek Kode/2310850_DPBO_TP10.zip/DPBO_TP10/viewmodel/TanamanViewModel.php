<?php
require_once 'model/Tanaman.php';
require_once 'model/Kebun.php';

class TanamanViewModel {
    private $tanaman;
    private $kebun;

    public function __construct() {
        $this->tanaman = new Tanaman();
        $this->kebun = new Kebun();
    }

    public function getTanamanList() {
        return $this->tanaman->getAll();
    }

    public function getTanamanById($id) {
        return $this->tanaman->getById($id);
    }

    public function getKebunList() {
        return $this->kebun->getAll();
    }

    public function addTanaman($nama, $jenis, $id_kebun) {
        return $this->tanaman->create($nama, $jenis, $id_kebun);
    }

    public function updateTanaman($id, $nama, $jenis, $id_kebun) {
        return $this->tanaman->update($id, $nama, $jenis, $id_kebun);
    }

    public function deleteTanaman($id) {
        return $this->tanaman->delete($id);
    }
}
?>
