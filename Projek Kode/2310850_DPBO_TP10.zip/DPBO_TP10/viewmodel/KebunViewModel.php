<?php
require_once 'model/Kebun.php';

class KebunViewModel {
    private $kebun;

    public function __construct() {
        $this->kebun = new Kebun();
    }

    public function getKebunList() {
        return $this->kebun->getAll();
    }

    public function getKebunById($id) {
        return $this->kebun->getById($id);
    }

    public function addKebun($nama, $lokasi, $luas) {
        return $this->kebun->create($nama, $lokasi, $luas);
    }

    public function updateKebun($id, $nama, $lokasi, $luas) {
        return $this->kebun->update($id, $nama, $lokasi, $luas);
    }

    public function deleteKebun($id) {
        return $this->kebun->delete($id);
    }
}
?>
