<?php
require_once 'config/Database.php';

class Panen {
    private $conn;
    private $table = 'panen';

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getAll() {
    $query = "
        SELECT 
            p.id_panen AS id,
            p.tanggal_panen AS tanggal,
            p.jumlah_kg AS jumlah,
            p.kualitas,
            t.nama_tanaman
        FROM $this->table p
        JOIN tanaman t ON p.id_tanaman = t.id_tanaman
    ";
    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    public function getById($id) {
    $query = "
        SELECT 
            p.id_panen,
            p.id_tanaman,
            p.tanggal_panen,
            p.jumlah_kg,
            p.kualitas,
            t.nama_tanaman
        FROM $this->table p
        JOIN tanaman t ON p.id_tanaman = t.id_tanaman
        WHERE p.id_panen = :id
    ";
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
    }


    public function create($id_tanaman, $tanggal, $jumlah, $kualitas) {
        $query = "INSERT INTO $this->table (id_tanaman, tanggal_panen, jumlah_kg, kualitas) VALUES (:id_tanaman, :tanggal, :jumlah, :kualitas)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_tanaman', $id_tanaman);
        $stmt->bindParam(':tanggal', $tanggal);
        $stmt->bindParam(':jumlah', $jumlah);
        $stmt->bindParam(':kualitas', $kualitas);
        return $stmt->execute();
    }

    public function update($id, $id_tanaman, $tanggal, $jumlah, $kualitas) {
        $query = "UPDATE $this->table SET id_tanaman = :id_tanaman, tanggal_panen = :tanggal, jumlah_kg = :jumlah, kualitas = :kualitas WHERE id_panen = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_tanaman', $id_tanaman);
        $stmt->bindParam(':tanggal', $tanggal);
        $stmt->bindParam(':jumlah', $jumlah);
        $stmt->bindParam(':kualitas', $kualitas);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM $this->table WHERE id_panen = :id");
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}
?>
