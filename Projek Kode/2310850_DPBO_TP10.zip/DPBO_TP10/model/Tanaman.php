<?php
require_once 'config/Database.php';

class Tanaman {
    private $conn;
    private $table = 'tanaman';

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getAll() {
        $query = "SELECT t.*, k.nama_kebun FROM $this->table t JOIN kebun k ON t.id_kebun = k.id_kebun";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $query = "SELECT t.*, k.nama_kebun FROM $this->table t JOIN kebun k ON t.id_kebun = k.id_kebun WHERE t.id_tanaman = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($nama, $jenis, $id_kebun) {
        $query = "INSERT INTO $this->table (nama_tanaman, jenis, id_kebun) VALUES (:nama, :jenis, :id_kebun)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nama', $nama);
        $stmt->bindParam(':jenis', $jenis);
        $stmt->bindParam(':id_kebun', $id_kebun);
        return $stmt->execute();
    }

    public function update($id, $nama, $jenis, $id_kebun) {
        $query = "UPDATE $this->table SET nama_tanaman = :nama, jenis = :jenis, id_kebun = :id_kebun WHERE id_tanaman = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nama', $nama);
        $stmt->bindParam(':jenis', $jenis);
        $stmt->bindParam(':id_kebun', $id_kebun);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM $this->table WHERE id_tanaman = :id");
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}
?>
