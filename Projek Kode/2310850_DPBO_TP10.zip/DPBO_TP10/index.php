<?php
require_once 'viewmodel/KebunViewModel.php';
require_once 'viewmodel/TanamanViewModel.php';
require_once 'viewmodel/PanenViewModel.php';

$entity = isset($_GET['entity']) ? $_GET['entity'] : 'panen';
$action = isset($_GET['action']) ? $_GET['action'] : 'list';

if ($entity == 'panen') {
    $viewModel = new PanenViewModel();
    if ($action == 'list') {
        $panenList = $viewModel->getPanenList();
        require_once 'views/panen/list.php';
    } elseif ($action == 'add') {
        $kebuns = $viewModel->getKebuns();
        $tanamans = $viewModel->getTanamans();
        require_once 'views/panen/form.php';
    } elseif ($action == 'edit') {
        $panen = $viewModel->getPanenById($_GET['id']);
        $kebuns = $viewModel->getKebuns();
        $tanamans = $viewModel->getTanamans();
        require_once 'views/panen/form.php';
    } elseif ($action == 'save') {
        $viewModel->addPanen($_POST['id_tanaman'], $_POST['tanggal'], $_POST['jumlah'], $_POST['kualitas']);
        header('Location: index.php?entity=panen');
    } elseif ($action == 'update') {
        $viewModel->updatePanen($_GET['id'], $_POST['id_tanaman'], $_POST['tanggal'], $_POST['jumlah'], $_POST['kualitas']);
        header('Location: index.php?entity=panen');
    } elseif ($action == 'delete') {
        $viewModel->deletePanen($_GET['id']);
        header('Location: index.php?entity=panen');
    }

} elseif ($entity == 'kebun') {
    $viewModel = new KebunViewModel();
    if ($action == 'list') {
        $kebunList = $viewModel->getKebunList();
        require_once 'views/kebun/list.php';
    } elseif ($action == 'add') {
        require_once 'views/kebun/form.php';
    } elseif ($action == 'edit') {
        $kebun = $viewModel->getKebunById($_GET['id']);
        require_once 'views/kebun/form.php';
    } elseif ($action == 'save') {
        $viewModel->addKebun($_POST['nama'], $_POST['lokasi'], $_POST['luas']);
        header('Location: index.php?entity=kebun');
    } elseif ($action == 'update') {
        $viewModel->updateKebun($_GET['id'], $_POST['nama'], $_POST['lokasi'], $_POST['luas']);
        header('Location: index.php?entity=kebun');
    } elseif ($action == 'delete') {
        $viewModel->deleteKebun($_GET['id']);
        header('Location: index.php?entity=kebun');
    }

} elseif ($entity == 'tanaman') {
    $viewModel = new TanamanViewModel();
    if ($action == 'list') {
        $tanamanList = $viewModel->getTanamanList();
        require_once 'views/tanaman/list.php';
    } elseif ($action == 'add') {
        $kebuns = $viewModel->getKebunList(); 
        require_once 'views/tanaman/form.php';
    } elseif ($action == 'edit') {
        $tanaman = $viewModel->getTanamanById($_GET['id']);
        $kebuns = $viewModel->getKebunList();
        require_once 'views/tanaman/form.php';
    } elseif ($action == 'save') {
        $viewModel->addTanaman($_POST['nama'], $_POST['jenis'], $_POST['id_kebun']);
        header('Location: index.php?entity=tanaman');
    } elseif ($action == 'update') {
        $viewModel->updateTanaman($_GET['id'], $_POST['nama'], $_POST['jenis'], $_POST['id_kebun']);
        header('Location: index.php?entity=tanaman');
    } elseif ($action == 'delete') {
        $viewModel->deleteTanaman($_GET['id']);
        header('Location: index.php?entity=tanaman');
    }
}
?>
